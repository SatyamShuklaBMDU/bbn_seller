<!DOCTYPE html>
<html>

<head>
    <title>Test Email</title>
</head>

<body>
    <p>This is a test email sent from Laravel.</p>
</body>

</html>
